// Storage layer: Netlify Blobs in production, JSON files locally for tests/dev.
import fs from 'node:fs';
import path from 'node:path';

let implPromise = null;

async function getImpl() {
  if (implPromise) return implPromise;
  implPromise = (async () => {
    if (process.env.NETLIFY) {
      // Production: Netlify Blobs (persistent across deploys, zero-config on the site)
      const { getStore } = await import('@netlify/blobs');
      const s = getStore('chatroom-data');
      return {
        async get(key) { return s.get(key, { type: 'json' }); },
        async set(key, value) { await s.setJSON(key, value); },
        async list(prefix) {
          const res = await s.list({ prefix });
          return res.blobs.map((b) => b.key).sort();
        },
        async del(key) { await s.delete(key); },
      };
    }
    // Local fallback (netlify dev / tests): JSON files under .data (or $CHAT_DATA_DIR)
    const dir = process.env.CHAT_DATA_DIR || path.join(process.cwd(), '.data');
    fs.mkdirSync(dir, { recursive: true });
    const fname = (k) => path.join(dir, k.replace(/[^a-zA-Z0-9_-]/g, '_') + '.json');
    return {
      async get(key) { try { return JSON.parse(fs.readFileSync(fname(key), 'utf8')); } catch { return null; } },
      async set(key, value) { fs.writeFileSync(fname(key), JSON.stringify(value)); },
      async list(prefix) {
        const p = prefix.replace(/[^a-zA-Z0-9_-]/g, '_');
        return fs.readdirSync(dir)
          .filter((n) => n.startsWith(p) && n.endsWith('.json'))
          .map((n) => n.slice(0, -5))
          .sort();
      },
      async del(key) { try { fs.unlinkSync(fname(key)); } catch { /* already gone */ } },
    };
  })();
  return implPromise;
}

export const store = {
  get: async (k) => (await getImpl()).get(k),
  set: async (k, v) => (await getImpl()).set(k, v),
  list: async (p) => (await getImpl()).list(p),
  del: async (k) => (await getImpl()).del(k),
};
