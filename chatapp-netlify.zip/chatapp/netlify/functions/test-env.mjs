// Test helper: point the store at a temp dir before api.mjs is imported.
// In production NETLIFY=1 makes api.mjs use real Netlify Blobs instead.
import fs from 'node:fs';
import path from 'node:path';

if (!process.env.NETLIFY) {
  process.env.CHAT_DATA_DIR = path.join(process.cwd(), '.test-data');
  fs.rmSync(process.env.CHAT_DATA_DIR, { recursive: true, force: true });
}

export const setEnv = { fresh: 0 };
