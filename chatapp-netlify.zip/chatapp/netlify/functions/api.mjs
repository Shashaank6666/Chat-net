// ChatRoom API — one serverless function, action-based routing.
// Runs on Netlify Functions (v2). Data lives in Netlify Blobs (persistent).
import bcrypt from 'bcryptjs';
import { store } from './store.mjs';

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { 'content-type': 'application/json', 'access-control-allow-origin': '*' },
  });

const slug = (s) => String(s || '').toLowerCase().trim().replace(/[^a-z0-9-_]/g, '').slice(0, 32);
const clean = (s, max) => String(s ?? '').trim().slice(0, max);
const keyNick = (s) => String(s || '').toLowerCase().trim().replace(/[^a-z0-9_-]/g, '').slice(0, 20);
const rand = () => Math.random().toString(36).slice(2, 8);
const now = () => Date.now();

const PRESENCE_TTL = 60_000;      // "online" window
const MEMBER_TTL = 5 * 60_000;    // member list window
const TYPING_TTL = 4_000;         // typing indicator window
const INVITE_TTL = 90_000;        // invite lifetime
const SESSION_TTL = 12 * 3_600_000;
const MAX_HISTORY = 200;

async function readBody(req) {
  try { return await req.json(); } catch { return {}; }
}

/* ---------- data helpers ---------- */

async function publicRoom(room) {
  const members = await roomMembers(room.id);
  return {
    id: room.id, name: room.name, owner: room.owner,
    hasPassword: room.hasPassword, createdAt: room.createdAt, members,
  };
}

async function roomMembers(roomId) {
  const keys = await store.list(`member:${roomId}:`);
  const out = [];
  for (const k of keys) {
    const s = await store.get(k);
    if (s && now() - s.lastSeen < MEMBER_TTL) out.push(s.nickname);
  }
  return out;
}

async function loadHistory(roomId) {
  const keys = await store.list(`m:${roomId}:`);
  const msgs = [];
  for (const k of keys) {
    const m = await store.get(k);
    if (m) msgs.push(m);
  }
  return msgs.slice(-MAX_HISTORY); // keys are ts-padded → already chronological
}

async function addMessage(roomId, msg) {
  const key = `m:${roomId}:${String(msg.ts).padStart(15, '0')}:${rand()}`;
  await store.set(key, msg);
  // cap history per room
  const keys = await store.list(`m:${roomId}:`);
  if (keys.length > MAX_HISTORY) {
    for (const k of keys.slice(0, keys.length - MAX_HISTORY)) await store.del(k);
  }
  return msg;
}

async function touchMember(roomId, nickname) {
  await store.set(`member:${roomId}:${keyNick(nickname)}`, {
    nickname: clean(nickname, 20), lastSeen: now(),
  });
}

/* ---------- actions ---------- */

const actions = {
  async 'create-room'(body) {
    const name = clean(body.name, 32);
    const nickname = clean(body.nickname, 20);
    if (!name) return json({ ok: false, error: 'Give your room a name 🏠' }, 400);
    const id = slug(name);
    if (!id) return json({ ok: false, error: 'Room name needs letters/numbers 🙃' }, 400);
    if (await store.get(`room:${id}`)) return json({ ok: false, error: 'That room name is taken. Try another!' }, 400);
    const pw = clean(body.password, 64);
    const room = {
      id, name, owner: nickname || 'someone',
      hasPassword: !!pw, createdAt: now(),
    };
    await store.set(`room:${id}`, room);
    if (pw) await store.set(`pw:${id}`, await bcrypt.hash(pw, 8));
    if (nickname) await touchMember(id, nickname);
    return json({ ok: true, room: await publicRoom(room) });
  },

  async 'join-room'(body) {
    const id = slug(body.roomId);
    const nickname = clean(body.nickname, 20);
    if (!nickname) return json({ ok: false, error: 'Pick a nickname first!' }, 400);
    const room = await store.get(`room:${id}`);
    if (!room) return json({ ok: false, error: 'Room not found 😢' }, 400);
    if (room.hasPassword) {
      const hash = await store.get(`pw:${id}`);
      const good = hash && (await bcrypt.compare(clean(body.password, 64), hash));
      if (!good) return json({ ok: false, error: 'Wrong password 🙈' }, 400);
    }
    await touchMember(id, nickname);
    await addMessage(id, { user: '', type: 'system', text: `${nickname} joined the party 🎉`, ts: now() });
    return json({ ok: true, room: await publicRoom(room), history: await loadHistory(id) });
  },

  async 'send-message'(body) {
    const id = slug(body.roomId);
    const nickname = clean(body.nickname, 20);
    const text = clean(body.text, 800);
    const type = body.type === 'emoji' ? 'emoji' : 'text';
    if (!id || !nickname || !text) return json({ ok: false, error: 'Missing message data' }, 400);
    const room = await store.get(`room:${id}`);
    if (!room) return json({ ok: false, error: 'Room not found 😢' }, 400);
    const session = await store.get(`member:${id}:${keyNick(nickname)}`);
    if (!session || now() - session.lastSeen > SESSION_TTL) {
      return json({ ok: false, error: 'Join the room first 🎈' }, 400);
    }
    const msg = { user: nickname, text, type, ts: now() };
    await addMessage(id, msg);
    return json({ ok: true, msg });
  },

  async 'state'(body) {
    const id = slug(body.roomId);
    const nickname = clean(body.nickname, 20);
    const since = Number(body.since) || 0;
    const room = await store.get(`room:${id}`);
    if (!room) return json({ ok: false, error: 'Room not found 😢' }, 400);
    if (nickname) await touchMember(id, nickname);

    const messages = (await loadHistory(id)).filter((m) => m.ts > since);

    const typers = [];
    for (const k of await store.list(`typing:${id}:`)) {
      const t = await store.get(k);
      if (t && now() - t.ts < TYPING_TTL && t.nickname !== nickname) typers.push(t.nickname);
    }
    return json({ ok: true, messages, typers, members: await roomMembers(id), hasPassword: room.hasPassword });
  },

  async 'presence'(body) {
    const nickname = clean(body.nickname, 20);
    if (nickname) {
      await store.set(`presence:${keyNick(nickname)}`, {
        nickname, ts: now(), roomId: slug(body.roomId) || null,
      });
    }
    const online = [];
    for (const k of await store.list('presence:')) {
      const p = await store.get(k);
      if (p && now() - p.ts < PRESENCE_TTL) online.push(p.nickname);
    }
    return json({ ok: true, online: [...new Set(online)] });
  },

  async 'typing'(body) {
    const id = slug(body.roomId);
    const nickname = clean(body.nickname, 20);
    if (!id || !nickname) return json({ ok: false, error: 'Missing data' }, 400);
    if (body.on === false) await store.del(`typing:${id}:${keyNick(nickname)}`);
    else await store.set(`typing:${id}:${keyNick(nickname)}`, { nickname, ts: now() });
    return json({ ok: true });
  },

  async invite(body) {
    const roomId = slug(body.roomId);
    const from = clean(body.from, 20);
    const to = clean(body.to, 20);
    const room = await store.get(`room:${roomId}`);
    if (!room) return json({ ok: false, error: 'Room not found' }, 400);
    const p = await store.get(`presence:${keyNick(to)}`);
    if (!p || now() - p.ts > PRESENCE_TTL) return json({ ok: false, error: `${to} is not online right now 😕` }, 400);
    const invite = {
      id: `${keyNick(to)}:${now()}:${rand()}`,
      roomId, roomName: room.name, hasPassword: room.hasPassword,
      password: room.hasPassword ? clean(body.password, 64) : '',
      from, to, ts: now(),
    };
    await store.set(`invite:${invite.id}`, invite);
    return json({ ok: true });
  },

  async inbox(body) {
    const nickname = keyNick(body.nickname);
    const invites = [];
    for (const k of await store.list('invite:')) {
      const inv = await store.get(k);
      if (!inv) continue;
      if (now() - inv.ts > INVITE_TTL) { await store.del(k); continue; }
      if (inv.to.toLowerCase().replace(/[^a-z0-9_-]/g, '') === nickname) invites.push(inv);
    }
    return json({ ok: true, invites });
  },

  async 'invite-close'(body) {
    if (body.id) await store.del(`invite:${body.id}`);
    return json({ ok: true });
  },

  async rooms() {
    const keys = await store.list('room:');
    const rooms = [];
    for (const k of keys) {
      const room = await store.get(k);
      if (room) rooms.push(await publicRoom(room));
    }
    return json({ ok: true, rooms });
  },
};

export default async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, {
    status: 204,
    headers: {
      'access-control-allow-origin': '*',
      'access-control-allow-methods': 'GET, POST, OPTIONS',
      'access-control-allow-headers': 'content-type',
    },
  });

  const url = new URL(req.url);
  const body = req.method === 'POST' ? await readBody(req) : {};
  const action = url.searchParams.get('action') || body.action;

  const handler = action && actions[action];
  if (!handler) return json({ ok: false, error: 'Unknown action' }, 404);
  try {
    // GET params merge into body for uniform handling
    const merged = { ...body };
    for (const [k, v] of url.searchParams) if (k !== 'action') merged[k] = v;
    return await handler(merged);
  } catch (err) {
    console.error('api error', action, err);
    return json({ ok: false, error: 'Server hiccup 🤖' }, 500);
  }
};

export const config = { path: '/api' };
