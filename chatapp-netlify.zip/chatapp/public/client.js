/* ============ ChatRoom client — Netlify serverless edition ============ */
/* Realtime via short-interval polling of the /api function (no WebSockets on Netlify). */

const $ = (id) => document.getElementById(id);
const state = { name: null, room: null, lastTs: 0, members: [], online: [], pollTimers: [] };

/* ---------------- API helper ---------------- */
async function api(action, body = {}) {
  const res = await fetch('/api?action=' + encodeURIComponent(action), {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ ...body, action }),
  });
  return res.json();
}

/* ---------------- helpers ---------------- */
function toast(text, ms = 2600) {
  const t = $('toast');
  t.textContent = text;
  t.classList.remove('hidden');
  clearTimeout(t._tm);
  t._tm = setTimeout(() => t.classList.add('hidden'), ms);
}
const esc = (s) => {
  const d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
};
const timeStr = (ts) => new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

function save() {
  localStorage.setItem('cr_name', state.name || '');
  localStorage.setItem('cr_room', state.room || '');
}

/* ---------------- pollers ---------------- */
function startPolling() {
  stopPolling();
  state.pollTimers = [
    setInterval(pollState, 1300),    // messages + members + typers
    setInterval(pollPresence, 2500), // online users (also keeps me "online")
    setInterval(pollInbox, 3500),    // incoming invites
  ];
}
function stopPolling() {
  state.pollTimers.forEach(clearInterval);
  state.pollTimers = [];
}

async function pollState() {
  if (!state.room) return;
  const res = await api('state', { roomId: state.room, nickname: state.name, since: state.lastTs });
  if (!res.ok) return;
  let added = false;
  for (const m of res.messages) {
    renderMsg(m);
    if (m.ts > state.lastTs) state.lastTs = m.ts;
    added = true;
  }
  if (added) {
    const box = $('messages');
    box.scrollTop = box.scrollHeight;
  }
  if (JSON.stringify(res.members) !== JSON.stringify(state.members)) {
    state.members = res.members;
    renderMembers(res.members);
  }
  const typers = res.typers || [];
  const label = typers.length ? `${typers.slice(0, 2).join(', ')} typing…` : '';
  const el = $('typingIndicator');
  if (el.dataset.label !== label) { el.dataset.label = label; }
  el.classList.toggle('hidden', typers.length === 0);
}

async function pollPresence() {
  const res = await api('presence', { nickname: state.name, roomId: state.room, listOnly: false });
  if (!res.ok) return;
  const online = (res.online || []).filter((u) => u !== state.name);
  if (JSON.stringify(online) !== JSON.stringify(state.online)) {
    state.online = online;
    renderOnlineFriends(online);
  }
}

async function pollInbox() {
  if (!state.name || pendingInvite) return;
  const res = await api('inbox', { nickname: state.name });
  if (!res.ok || !res.invites.length) return;
  const inv = res.invites[0];
  pendingInvite = inv;
  $('incomingText').textContent = `${inv.from} invited you to #${inv.roomName}!`;
  $('incomingModal').classList.remove('hidden');
  await api('invite-close', { id: inv.id }); // pop it from the inbox
}

/* ---------------- register / entry ---------------- */
async function register(name) {
  state.name = name;
  save();
  $('entryScreen').classList.add('hidden');
  $('chatScreen').classList.remove('hidden');
  $('roomTitle').textContent = 'No room yet — create or join one!';
  $('membersInfo').textContent = 'connecting…';
  await refreshRooms();
  startPolling();
  pollPresence();
  toast(`Welcome, ${name}! 🎉`);
}

$('startBtn').onclick = () => {
  const name = $('nameInput').value.trim();
  if (!name) return toast('Type a nickname first 😅');
  register(name);
};
$('nameInput').addEventListener('keydown', (e) => e.key === 'Enter' && $('startBtn').click());
$('createBtn').onclick = () => window.openCreate();

const savedName = localStorage.getItem('cr_name') || '';
if (savedName) $('nameInput').value = savedName;

/* ---------------- create room ---------------- */
$('confirmCreateBtn').onclick = async () => {
  const name = $('createNameInput').value.trim();
  const pw = $('createPwInput').value;
  if (!name) return toast('Give your room a name 🏠');
  if (!state.name) { closeCreate(); return toast('Pick a nickname first 😅'); }
  const res = await api('create-room', { name, password: pw, nickname: state.name });
  if (!res.ok) return toast(res.error);
  closeCreate();
  joinRoom(res.room.id, pw);
};
$('cancelCreateBtn').onclick = closeCreate;
function closeCreate() {
  $('createModal').classList.add('hidden');
  $('createNameInput').value = '';
  $('createPwInput').value = '';
}
window.openCreate = () => {
  if (!state.name) {
    const n = $('nameInput').value.trim();
    if (!n) return toast('Pick a nickname first 😅');
    register(n);
  }
  $('createModal').classList.remove('hidden');
};

/* ---------------- join room ---------------- */
async function joinRoom(roomId, password) {
  if (!state.name) {
    const n = $('nameInput').value.trim();
    if (!n) return toast('Type your nickname first 😅');
    await register(n);
  }
  const res = await api('join-room', { roomId, password, nickname: state.name });
  if (!res.ok) return toast(res.error);
  state.room = res.room.id;
  state.lastTs = 0;
  save();
  $('roomTitle').textContent = `# ${res.room.name}`;
  $('membersInfo').textContent = `${res.room.members.length} members · ID: ${res.room.id}`;
  $('messages').innerHTML = '';
  for (const m of res.history || []) renderMsg(m);
  const box = $('messages');
  box.scrollTop = box.scrollHeight;
  state.members = res.room.members;
  renderMembers(res.room.members);
  $('entryScreen').classList.add('hidden');
  $('chatScreen').classList.remove('hidden');
  startPolling();
  toast(`Joined #${res.room.name} 🥳`);
}

$('joinBtn').onclick = () => {
  const roomId = $('joinRoomInput').value.trim();
  if (!roomId) return toast('Enter a room ID 🔑');
  joinRoom(roomId, $('joinPwInput').value);
};

/* ---------------- rooms list ---------------- */
async function refreshRooms() {
  const res = await api('rooms');
  if (!res.ok) return;
  const box = $('roomsList');
  const live = (res.rooms || []).filter((r) => r.members.length > 0);
  if (!live.length) {
    box.innerHTML = '<div class="empty-rooms">No live rooms yet — create one! 🛠️</div>';
    return;
  }
  box.innerHTML = '';
  live.forEach((r) => {
    const d = document.createElement('div');
    d.className = 'room-chip';
    d.innerHTML = `<div><div class="rname">${esc(r.name)}</div>
      <div class="rmeta">ID: ${esc(r.id)} · ${r.members.length} online</div></div>
      <span class="pill">${r.hasPassword ? '🔒' : 'OPEN'}</span>`;
    d.onclick = () => {
      $('joinRoomInput').value = r.id;
      if (r.hasPassword) {
        $('joinPwInput').focus();
        toast('This room needs a password 🔒');
      } else {
        $('joinBtn').click();
      }
    };
    box.appendChild(d);
  });
}
setInterval(refreshRooms, 5000);

/* ---------------- online users ---------------- */
function renderOnlineFriends(list) {
  const box = $('onlineFriends');
  box.innerHTML = '';
  (list || []).forEach((u) => {
    const c = document.createElement('span');
    c.className = 'friend-chip';
    c.textContent = u;
    c.onclick = () => {
      $('inviteNameInput').value = u;
      document.querySelectorAll('.friend-chip').forEach((x) => x.classList.remove('sel'));
      c.classList.add('sel');
    };
    box.appendChild(c);
  });
  if (!list || !list.length) box.innerHTML = '<span class="empty-rooms">No one else online right now 😴</span>';
}

/* ---------------- messaging ---------------- */
function sendMsg(text, type) {
  if (!state.room) return toast('Join a room first! 🎈');
  if (!text.trim()) return;
  api('send-message', { roomId: state.room, nickname: state.name, text: text.trim(), type });
  pollState(); // show my own message immediately
}

$('sendBtn').onclick = () => {
  sendMsg($('msgInput').value, 'text');
  $('msgInput').value = '';
};
$('msgInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { sendMsg($('msgInput').value, 'text'); $('msgInput').value = ''; }
});

/* typing indicator — send state to server */
let typingTm = null;
$('msgInput').addEventListener('input', () => {
  if (!state.room) return;
  api('typing', { roomId: state.room, nickname: state.name, on: true });
  clearTimeout(typingTm);
  typingTm = setTimeout(() => api('typing', { roomId: state.room, nickname: state.name, on: false }), 1200);
});

function renderMsg(m) {
  const box = $('messages');
  const d = document.createElement('div');
  if (m.type === 'system') {
    d.className = 'msg system';
    d.textContent = m.text;
  } else if (m.type === 'emoji') {
    d.className = 'msg emoji-msg ' + (m.user === state.name ? 'mine' : 'theirs');
    d.innerHTML = `<span class="who">${esc(m.user)}</span><span class="emo">${esc(m.text)}</span>
      <span class="when">${timeStr(m.ts)}</span>`;
  } else {
    d.className = 'msg ' + (m.user === state.name ? 'mine' : 'theirs');
    d.innerHTML = `${m.user !== state.name ? `<span class="who">${esc(m.user)}</span>` : ''}${esc(m.text)}
      <span class="when">${timeStr(m.ts)}</span>`;
  }
  box.appendChild(d);
  box.scrollTop = box.scrollHeight;
}

function renderMembers(members) {
  $('membersInfo').textContent = `${members.length} members · ID: ${state.room}`;
}

/* ---------------- emoji picker ---------------- */
const EMOJIS = {
  smileys: ['😀','😃','😄','😁','😆','😅','🤣','😂','🙂','😉','😊','😍','😘','😜','🤪','🤗','🤔','🤨','😐','🙄','😴','🤤','😷','🤒','🥳','😎','🤓','🥺','😢','😭','😤','😡','🤯','😱','🥶','🥵','😇','🤠','🥰','😱'],
  gestures: ['👍','👎','👌','✌️','🤞','🤟','🤘','🤙','👋','🖐️','🙌','👏','🙏','💪','🦾','🤝','🫶','👊','🤛','🤜','✊'],
  hearts: ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','💕','💞','💓','💗','💖','💘','💝','💔','❣️','💟','😻','😍'],
  party: ['🎉','🎊','🎈','🎁','🎂','🍰','🥳','🍾','🥂','🍻','🎵','🎶','🎤','🎧','🔥','⭐','✨','💥','🎆','🎇','🪩','💃','🕺','🚀','🏆','🥇','👑','🌟'],
  animals: ['🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🐨','🐯','🦁','🐮','🐷','🐸','🐵','🐔','🐧','🐦','🦄','🐝','🦋','🐢','🐙','🦈','🐬','🐳'],
  food: ['🍕','🍔','🍟','🌮','🌯','🍿','🍩','🍪','🎂','🍫','🍬','🍭','🍦','🥤','☕','🍺','🍓','🍉','🍇','🥑','🍜','🍣'],
};
let emojiCat = 'smileys';
function renderEmojiGrid() {
  const grid = $('emojiGrid');
  grid.innerHTML = '';
  EMOJIS[emojiCat].forEach((e) => {
    const b = document.createElement('button');
    b.textContent = e;
    b.onclick = () => sendMsg(e, 'emoji');
    grid.appendChild(b);
  });
}
renderEmojiGrid();

$('emojiBtn').onclick = () => $('emojiPanel').classList.toggle('hidden');
document.querySelectorAll('.emoji-tabs .tab').forEach((t) => {
  t.onclick = () => {
    document.querySelectorAll('.emoji-tabs .tab').forEach((x) => x.classList.remove('active'));
    t.classList.add('active');
    emojiCat = t.dataset.cat;
    renderEmojiGrid();
  };
});

/* ---------------- invite ---------------- */
$('inviteBtn').onclick = () => {
  if (!state.room) return toast('Join a room first! 🎈');
  renderOnlineFriends(state.online);
  $('inviteModal').classList.remove('hidden');
};
$('cancelInviteBtn').onclick = () => $('inviteModal').classList.add('hidden');
$('confirmInviteBtn').onclick = async () => {
  const to = $('inviteNameInput').value.trim();
  if (!to) return toast('Who are you inviting? 👀');
  const res = await api('invite', { roomId: state.room, from: state.name, to });
  if (res.ok) { toast(`Invite sent to ${to} 📨`); $('inviteModal').classList.add('hidden'); }
  else toast(res.error);
};

/* incoming invite */
let pendingInvite = null;
$('acceptBtn').onclick = () => {
  if (!pendingInvite) return;
  joinRoom(pendingInvite.roomId, pendingInvite.password || '');
  pendingInvite = null;
  $('incomingModal').classList.add('hidden');
};
$('declineBtn').onclick = () => {
  pendingInvite = null;
  $('incomingModal').classList.add('hidden');
};

/* ---------------- back button ---------------- */
$('backBtn').onclick = () => {
  state.room = null;
  state.lastTs = 0;
  save();
  $('chatScreen').classList.add('hidden');
  $('entryScreen').classList.remove('hidden');
  $('roomTitle').textContent = 'No room yet — create or join one!';
  refreshRooms();
};
